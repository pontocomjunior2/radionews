import { GoogleGenerativeAI } from '@google/generative-ai';

const genAI = new GoogleGenerativeAI('AIzaSyCjAT9b9WpRqgxRqoBGQkX6NtXPmlFYiTU');

export async function rewriteNewsArticle(text: string, targetLength: number): Promise<string> {
  const model = genAI.getGenerativeModel({ model: 'gemini-pro' });

  const prompt = `
    Rewrite the following news article for natural text-to-speech narration in Brazilian Portuguese. 
    Follow these guidelines:
    - Target length: ${targetLength} seconds of speech
    - Remove abbreviations and expand them into full words
    - Remove dates in parentheses
    - Convert numbers into written form
    - Use natural sentence structure
    - Maintain journalistic tone
    - Optimize for TTS pronunciation
    - Remove special characters that might affect speech
    - Keep proper names but ensure they're in a format suitable for pronunciation

    Input text:
    ${text}
  `;

  try {
    const result = await model.generateContent(prompt);
    const response = await result.response;
    return response.text();
  } catch (error) {
    console.error('Error rewriting news article:', error);
    throw new Error('Failed to process news article with Gemini AI');
  }
}